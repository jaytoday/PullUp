# @askwithai/sdk

Call AskWithAI Decision Runtimes from your app: a typed client, `createDecision`, a faux server for tests (`@askwithai/sdk/testing`), an AgentRun decision provider (`@askwithai/sdk/agentrun`), and the `askwithai` command.

Documentation: `docs/integrating/sdk.md` and `docs/integrating/cli.md` in the AskWithAI repository.
