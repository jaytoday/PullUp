# @askwithai/react

AskWithAI's web kit on Astryx: `DecisionFeed`, `DecisionInspector`, `ReviewQueue`, `QualityPanel`, `ShadowComparison`, `ServingModeControl` inside `AskWithAIProvider`, and `createAskWithAIHandler` (`@askwithai/react/server`) for the host's API route. Documentation: `docs/web-kit.md` in the AskWithAI repository.
